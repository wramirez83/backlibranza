export default interface TextTopsInterface{
    icons: string,
    word_one: string,
}